---
name: cursor-toys-http
description: >-
  Guides creating, organizing, and testing HTTP request files (.req, .request)
  with CursorToys in the project http folder, project-root .env environments,
  CodeLens actions, hooks (__before__/__after__), response chaining
  (@SETTER/@GETTER), and the cursortoys CLI. Use when working in .cursor/http,
  .vscode/http, or .ai/http, writing API requests, env variables, assertions,
  or running npx cursortoys http test.
---

# CursorToys HTTP requests

Use this skill when the user works with `{{HTTP_FOLDER}}`, `.req` / `.request` files, API testing, or HTTP environments.

## Folder layout

Default location: **`{{HTTP_FOLDER}}`** (configured via `cursorToys.baseFolder`, e.g. `cursor` → `.cursor/http`).

Recommended organization:

```
{{HTTP_FOLDER}}/
  README.md              # Optional: what this suite covers
  health.req             # Smoke / health checks
  auth/
    __before__.req       # Optional: setup (runs before other files in folder)
    login.req
    __after__.req        # Optional: teardown (runs after other files in folder)
  users/
    crud.req
  integrations/
    partner-api.req
```

**Naming:** lowercase, hyphens (`user-profile.req`). One domain or feature per file when possible.

**Reserved hook files** (per directory; CLI only, not discovered twice as normal tests):

| File | Role |
|------|------|
| `__before__.req` / `__before__.request` | Setup before other `.req` files in the same folder |
| `__after__.req` / `__after__.request` | Teardown after other `.req` files in the same folder |

Execution order for `npx cursortoys http test -f <folder>` or `-f <file>`: **`__before__` → main file(s) → `__after__`**. Variables and `@SETTER` from `__before__` apply to later files in the same run. Terminal output prefixes hook phases as `before:` and `after:`.

**Do not** put `.env*` files inside `http/` — environments live at the **workspace root**.

## Request file format

Use **REST Client** syntax (required for assertions and CLI):

```http
# @env dev
# @var API_BASE=https://api.example.com

## List users
GET {{API_BASE}}/users
Accept: application/json

###

## Create user
POST {{API_BASE}}/users
Content-Type: application/json

{"name": "Ada"}
```

| Mechanism | Purpose |
|-----------|---------|
| `## Title` | Section; each gets its own **Send Request** / **Run assertions** CodeLens |
| `###` | Hard separator between request blocks (CLI runs blocks separately when testing a file) |
| `# @env name` | Use workspace `.env.name` (or `.env` for `default`) |
| `# @var KEY=value` | Inline variable; file or section scope |
| `{{VAR}}` | Substitute from `# @var` then from active `.env*` |
| `# @delay(ms)` | Wait before the block runs |

**Helpers:** `{{@uuid()}}`, `{{@datetime}}`, `{{@prompt("label")}}`, `{{@randomIn(1,10)}}`, `{{@randomString(8)}}`, `{{@randomFrom("a","b")}}`, `{{@userAgent()}}`, `{{@ip()}}`, `{{@lorem(5)}}`.

## Environments

At **project root** (not under `http/`):

- `.env` — default
- `.env.dev`, `.env.staging`, `.env.prod`, etc.
- `.env.local` — local overrides (often gitignored)
- `.env.example` — documentation only

Switch in the editor: **CursorToys: Select HTTP Environment** (status bar shows the active env).

## Assertions

After a request, add a block comment:

```http
GET {{API_BASE}}/users/1
/*
 * @assert("ok", "res.status", "equals", 200)
 * @assert("res.body.id", "equals", 1)
 * @assert("res.body.email", "contains", "@")
 */
```

Common operators: `equals`, `notEquals`, `contains`, `gt`, `gte`, `lt`, `lte`, `isString`, `isNumber`, `isArray`, `isJson`, `isEmpty`, `isNotEmpty`, `matches`.

## Response chaining (`@SETTER` / `@GETTER`)

Capture a value from one response and reuse it in the next block, file, or hook run (CLI; same variable map as `# @var`):

```http
## Public user profile
GET {{GITHUB_API}}/users/{{GITHUB_USER}}
Accept: application/vnd.github+json

/*
 * @assert("Avatar URL is set", "res.body.avatar_url", "contains", "avatars")
 * @SETTER("AVATAR_URL", "res.body.avatar_url")
 */

###

## Public user repositories
# @getter AVATAR_URL
GET {{GITHUB_API}}/users/{{GITHUB_USER}}/repos?per_page=5&ref={{AVATAR_URL}}
Accept: application/vnd.github+json

/*
 * @getter("AVATAR_URL")
 * @assert("repos ok", "res.status", "equals", 200)
 */
```

| Annotation | Purpose |
|------------|---------|
| `@SETTER("KEY", "res.body.path")` | After the block's request, stores the resolved value in `KEY` (case-insensitive) |
| `# @getter KEY` | Fails before the block runs if `KEY` is missing |
| `/* @getter("KEY") */` | Same validation inside a comment block |
| `{{KEY}}` | Substitute in URL, headers, body, or assertion expected values |

Sources for `KEY`: `# @var`, `.env*`, `@SETTER` from an earlier block/file, or `--var` on the CLI. Use getters when a block depends on a value produced earlier in the same `http test` run.

Combine with hooks: `__before__.req` can `@SETTER` login tokens; normal `.req` files use `# @getter` and `{{VAR}}`.

## Install this skill

- **CLI:** `npx cursortoys skill install http` (personal) or `npx cursortoys skill install http -t project -p .` (project). Use `--force` to reinstall.
- **Extension:** right-click `{{HTTP_FOLDER}}` in Explorer → **CursorToys: Add Skill: HTTP Requests Documentation**.

## Editor workflow

1. Create or edit `.req` / `.request` under `{{HTTP_FOLDER}}`.
2. Use **Send Request** CodeLens on a section.
3. Response: reusable **panel** by default (`cursorToys.httpRequestResponseView`: `panel` | `editor`).
4. **Run assertions** CodeLens runs CLI tests for that file in the integrated terminal.

Settings: `cursorToys.httpRequestTimeout`, `cursorToys.httpDefaultEnvironment`, `cursorToys.httpAssertionsEnabled`.

## CLI (cursortoys)

The **CursorToys CLI** (`cursortoys-cli` on npm, binary `cursortoys`) matches extension behavior. Prefer **`npx`** when the CLI is not installed globally.

```bash
# All request files under {{HTTP_FOLDER}} (per-folder: before → tests → after)
npx cursortoys http test

# One file (still runs __before__/__after__ in that file's directory)
npx cursortoys http test -f {{HTTP_FOLDER}}/auth/login.req

# Whole feature folder (hooks + all .req in folder)
npx cursortoys http test -f {{HTTP_FOLDER}}/auth

# Environment + verbose
npx cursortoys http test -f {{HTTP_FOLDER}}/api.req -e staging -V

# Override variables
npx cursortoys http test -f api.req --var BASE_URL=https://localhost:3000
```

| Flag | Meaning |
|------|---------|
| `-p, --project <dir>` | Workspace root |
| `--base-folder <name>` | e.g. `cursor` (or `CURSORTOYS_BASE_FOLDER`) |
| `-e, --env <name>` | Override `# @env` |
| `-f, --file <path>` | Single `.req` / `.request` |
| `-V, --verbose` | Print request/response |
| `--var key=value` | Override `{{key}}` |

Full CLI reference for agents: `npx cursortoys --llm`

**Requirements:** Node.js 18+, `curl` on PATH.

## Agent checklist

When helping with HTTP files in this project:

1. Read existing `{{HTTP_FOLDER}}` layout before adding files.
2. Prefer `##` sections and `{{variables}}`; never hardcode secrets in `.req` files.
3. Put env-specific URLs/tokens in root `.env.*`, not in the request body when avoidable.
4. Add `@assert` blocks for status and critical JSON fields on new endpoints.
5. Use `@SETTER` / `# @getter` when a flow needs IDs or tokens from a prior response; put shared setup in `__before__.req` when a whole folder shares login/seed.
6. Verify with `npx cursortoys http test -f <file-or-folder>` from the workspace root (or extension **Run assertions**).

## Troubleshooting

| Issue | Check |
|-------|--------|
| CodeLens missing | File under `{{HTTP_FOLDER}}`, extension `.req` or `.request`, reload window |
| Variables empty | Matching `.env.<name>` at project root; `# @env` name; status bar env |
| Request fails | `curl` installed; URL reachable; timeout setting |
| CLI not found | `npx cursortoys http test` or `npm i -g cursortoys-cli` |
| `GETTER: variável não definida` | Prior block/file needs `@SETTER`, `# @var`, or `.env`; run folder so `__before__` runs first |
| Hooks skipped | Target a folder or a file inside it so sibling `__before__`/`__after__` are found |
