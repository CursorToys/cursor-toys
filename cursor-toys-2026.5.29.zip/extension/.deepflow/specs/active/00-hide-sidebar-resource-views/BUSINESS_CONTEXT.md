# Business Context — Hide Sidebar Resource Views

## Problem

The CursorToys explorer sidebar shows seven personal-resource views (Commands, Prompts, Skills, MCPB Packages, etc.). Power users who only use a subset (e.g. Skills + MCPB) must scroll past unused sections. There is no setting to hide individual views.

## Goal

Let users control which sidebar resource sections appear via **Settings**, without removing underlying functionality (commands, import, context menus on files still work).

## User Stories

1. As a user who never uses personal Commands, I can hide the **Commands** view so it does not appear in the sidebar.
2. As a user, I can hide any combination of: Notepads, Commands, Prompts, Cursor Plans, Skills, Cursor Hooks, MCPB Packages.
3. As a user, when I change the setting, the sidebar updates without reloading the window (if VS Code allows; otherwise document reload requirement).
4. As a user, defaults show **all** views (backward compatible).

## Out of Scope

- Hiding CursorToys context menus on workspace files (explorer context) — only sidebar **views**.
- Hiding recommendations panel / spending status bar / other non-tree UI.
- Per-workspace vs global policy changes beyond standard VS Code configuration scopes.

## Acceptance Criteria

- [ ] New setting `cursorToys.sidebar.hiddenViews` (array of resource keys) documented in `package.json` with enum items matching each view.
- [ ] Default `[]` (empty) — all views visible.
- [ ] Hiding `commands` removes `cursor-toys.userCommands` from the explorer sidebar.
- [ ] Hiding `mcpb` removes `cursor-toys.userMcpb` from the sidebar.
- [ ] Same behavior for: `notepads`, `prompts`, `plans`, `skills`, `hooks`.
- [ ] View title actions (refresh, create, etc.) do not appear for hidden views.
- [ ] Changing the setting at runtime updates visibility without requiring extension reinstall.
- [ ] `CHANGELOG.md` entry under Added/Changed.
- [ ] `npm run compile` passes with no new TypeScript errors.

## Manual Test Plan

1. Open Settings → search `cursorToys sidebar hidden`.
2. Add `commands` and `mcpb` to hidden list → Commands and MCPB Packages sections disappear from sidebar.
3. Remove `commands` → Commands section reappears.
4. Reload window → settings persist; hidden views stay hidden.
5. Verify a hidden resource still works via Command Palette (e.g. refresh commands command) if commands remain registered.
