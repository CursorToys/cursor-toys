# Approach — Hide Sidebar Resource Views

**Task size:** Medium  
**Estimated effort:** 3–5 hours

## Design Decision

VS Code `views.explorer[].when` does not reliably express “array contains item” for configuration. Use **context keys** set from code (pattern used across the ecosystem):

| Resource key | Context key | View ID |
|--------------|-------------|---------|
| `notepads` | `cursorToys.sidebar.notepadsVisible` | `cursor-toys.userNotepads` |
| `commands` | `cursorToys.sidebar.commandsVisible` | `cursor-toys.userCommands` |
| `prompts` | `cursorToys.sidebar.promptsVisible` | `cursor-toys.userPrompts` |
| `plans` | `cursorToys.sidebar.plansVisible` | `cursor-toys.userPlans` |
| `skills` | `cursorToys.sidebar.skillsVisible` | `cursor-toys.userSkills` |
| `hooks` | `cursorToys.sidebar.hooksVisible` | `cursor-toys.userHooks` |
| `mcpb` | `cursorToys.sidebar.mcpbVisible` | `cursor-toys.userMcpb` |

`visible = !hiddenViews.includes(key)` — default all `true` when `hiddenViews` is empty.

## Implementation Steps

### Step 1 — Configuration schema

**File:** `package.json` → `contributes.configuration`

Add:

```json
"cursorToys.sidebar.hiddenViews": {
  "type": "array",
  "items": {
    "type": "string",
    "enum": ["notepads", "commands", "prompts", "plans", "skills", "hooks", "mcpb"]
  },
  "default": [],
  "description": "Sidebar resource views to hide in the CursorToys explorer section."
}
```

Use `markdownDescription` if other settings do — list human-readable labels in description.

### Step 2 — Sidebar visibility module

**New file:** `src/sidebarVisibility.ts`

- Export `SidebarResourceKey` union type matching enum.
- Export `ALL_SIDEBAR_RESOURCE_KEYS` constant array.
- Export `syncSidebarViewVisibility(): void` — reads `cursorToys.sidebar.hiddenViews`, calls `vscode.commands.executeCommand('setContext', key, visible)` for each resource.
- Export `isSidebarResourceHidden(key): boolean` for optional use in extension (skip watchers).

Keep logic pure and testable (normalize: lowercase, filter unknown keys).

### Step 3 — Wire activation + config watcher

**File:** `src/extension.ts`

- Call `syncSidebarViewVisibility()` once during `activate()` (before or after tree view registration — both work; before is slightly cleaner).
- Extend existing `onDidChangeConfiguration` handler (or add adjacent listener) when `e.affectsConfiguration('cursorToys.sidebar.hiddenViews')` → call `syncSidebarViewVisibility()`.

Tree views and providers **remain registered** (commands still work); only UI visibility changes. Optional follow-up: guard FileSystemWatcher creation with `!isSidebarResourceHidden('commands')` — **defer** unless perf issue; not required for AC.

### Step 4 — package.json view `when` clauses

**File:** `package.json` → `contributes.views.explorer`

Replace `"when": "true"` per view:

```json
"when": "cursorToys.sidebar.notepadsVisible"
```

(and corresponding context key for each view).

Menus under `view/title` and `view/item` already use `view == cursor-toys.userX` — no change needed.

### Step 5 — Documentation

- `CHANGELOG.md` — user-facing note (English).
- No change to root `AGENTS.md` unless adding a permanent convention bullet (optional one-liner about sidebar settings).

## Files Touched (expected)

| File | Action |
|------|--------|
| `src/sidebarVisibility.ts` | Create |
| `src/extension.ts` | Import + sync on activate + config change |
| `package.json` | Setting + view `when` clauses |
| `CHANGELOG.md` | Entry |

## Risks & Mitigations

| Risk | Mitigation |
|------|------------|
| Context keys not applied before views render | Call `syncSidebarViewVisibility()` at start of `activate()` |
| Invalid keys in user settings.json | Filter to known enum in `syncSidebarViewVisibility` |
| User expects hidden = disabled | Document that Command Palette / file actions still work |

## Sequence

```mermaid
flowchart LR
  A[User edits hiddenViews] --> B[onDidChangeConfiguration]
  B --> C[syncSidebarViewVisibility]
  C --> D[setContext per resource]
  D --> E[views.when re-evaluates]
  E --> F[Sidebar sections show/hide]
```
