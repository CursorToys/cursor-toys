# Business Context — HTTP envs na raiz do projeto

## Problem

Hoje as variáveis HTTP ficam em `.{baseFolder}/http/{environmentsFolder}/` (ex.: `.cursor/http/.environments/.env.dev`). Isso duplica o padrão já usado por apps (`.env`, `.env.local` na raiz) e obriga uma pasta dedicada só para a extensão.

## Goal

Alinhar o HTTP da extensão ao **layout padrão de env do projeto**: arquivos `.env*` na **raiz do workspace**, sem pasta `environments` / `.environments` sob `http/`.

## Breaking change (explicit)

| Antes | Depois |
|-------|--------|
| `.cursor/http/environments/` ou `.cursor/http/.environments/` | **Sem suporte** — não ler nem criar essa pasta |
| Setting `cursorToys.environmentsFolder` | **Removida** |
| Comandos que abrem/inicializam pasta de environments HTTP | Redirecionados para raiz (`.env` / `.env.example`) ou removidos se redundantes |
| Import/share de bundles com path `environments/...` | Importar `.env*` na **raiz**; geradores não embutem mais subpasta environments |

## Acceptance criteria

1. **Resolução de variáveis**: `# @env dev` carrega `{workspaceRoot}/.env.dev`; `# @env default` carrega `{workspaceRoot}/.env`; fallback documentado se só existir `.env`.
2. **Descoberta**: autocomplete e `getAvailableEnvironments()` listam envs a partir de `.env*` na raiz (ex.: `default`, `dev`, `local` para `.env.local`), excluindo `.env.example` da lista executável.
3. **Watchers**: alterações em `.env` / `.env.local` / `.env.*` na raiz invalidam cache e atualizam hover/execução HTTP.
4. **UI/UX**: mensagens de hover, skill HTTP e README apontam para raiz do projeto, não para `http/environments`.
5. **Sem regressão HTTP**: executar request com `{{var}}` e decorator `# @env` continua funcionando com arquivos na raiz.
6. **Breaking**: arquivos apenas em `.cursor/http/.environments/` **não** são lidos; CHANGELOG documenta migração (copiar `.env*` para a raiz).
7. **Config**: `cursorToys.environmentsFolder` removida de `package.json` e código; compilação limpa.
8. **Share/import**: bundles e import de env não usam mais subpasta `environments` sob `http/`.
9. **Visualização**: CodeLens/context para `.env*` na raiz (onde aplicável); arquivos em `http/environments/` deixam de ser tratados como tipo `env` da extensão.

## Out of scope

- Parser avançado de dotenv (expansão `${VAR}`, multiline) além do que já existe.
- Envs pessoais fora do workspace (continua só projeto).
- Migração automática de arquivos antigos para a raiz (apenas documentação).

## Success metrics

- Usuário com `.env` e `.env.local` na raiz executa HTTP sem criar pasta em `.cursor/http/`.
- Nenhuma referência ativa a `getEnvironmentsPath()` / `environmentsFolder` no código de produção.

## Stakeholders

- Usuários da extensão com projetos que já usam dotenv na raiz.
- Mantenedores (docs + CHANGELOG + possível major bump).
