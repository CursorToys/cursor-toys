# Approach — Migrar HTTP environments para raiz do projeto

**Size:** Medium–Large (10+ arquivos, breaking change)

## Overview

```mermaid
flowchart LR
  subgraph before [Before]
    REQ[".req + # @env dev"]
    EM1[EnvironmentManager]
    DIR[".cursor/http/.environments/.env.dev"]
    REQ --> EM1 --> DIR
  end
  subgraph after [After]
    REQ2[".req + # @env dev"]
    EM2[EnvironmentManager]
    ROOT["{workspace}/.env.dev"]
    REQ2 --> EM2 --> ROOT
  end
```

Centralizar resolução de path em um helper novo; remover caminho legado.

## Step 1 — Path helper na raiz

- Add `getProjectEnvFilePath(workspacePath, envName)` in `utils.ts`:
  - `default` → `{workspace}/.env`
  - else → `{workspace}/.env.{envName}` (e.g. `local` → `.env.local`)
- Add `getProjectEnvRoot(workspacePath)` → `workspacePath` (explicit API for watchers/docs).
- Add `listProjectEnvFiles(workspacePath)` scanning root only, filter `.env.example` from runnable envs.
- Mark `getEnvironmentsPath()` / `getEnvironmentsFolderName()` **deprecated → delete** in step 2 (no callers left).

## Step 2 — EnvironmentManager

- `loadEnvironment`, `getAvailableEnvironments`, `createEnvironment`, `initializeDefaultEnvironments`, file watchers: use project root paths only.
- Stop creating `.{baseFolder}/http/{environments}/` on activate.
- Watcher pattern: `RelativePattern(workspaceRoot, '.env*')` at workspace root.
- `createEnvironment` / init: write `.env.example` (and optional `.env`) at **workspace root**, not under `http/`.

## Step 3 — utils file typing & HTTP paths

- `getFileTypeFromPath`: remove `env` detection under `http/.../environments`; detect `env` for `.{workspace}/.env*` at root (basename starts with `.env`).
- `isEnvironmentFile()`: align with root-only rule.
- HTTP request detection: drop exclusions for `environmentsFolder` segments (only `http/` folder matters).

## Step 4 — Providers & executor messages

- `httpEnvironmentProviders.ts`: hover/completion docs reference `{workspace}/.env.{name}`.
- Grep `environments/` / `.environments` in `src/` strings and fix.

## Step 5 — extension commands & package.json

- `cursor-toys.openEnvironments` → open workspace root or reveal `.env` if exists.
- `cursor-toys.initializeEnvironments` → create root `.env` + `.env.example` (rename command label if needed).
- Remove `cursorToys.environmentsFolder` from `package.json` + `configuration` enums.
- Update context menu `when` clauses: root `.env*` instead of `http/.../environments/`.

## Step 6 — Share / import / CodeLens

- `shareableGenerator.ts`, `shareableImporter.ts`, `deeplinkImporter.ts` (if env paths): env files target workspace root; remove bundle paths with `environments/` subfolder.
- `envCodeLensProvider.ts`: root `.env` only (remove `http/environments` guard).
- Review `gistManager` / `generateShareableForEnvFolder` — deprecate env-folder bundle or map to “export root env files”.

## Step 7 — Documentation & telemetry

- `README.md`, `CHANGELOG.md` (**Breaking Changes**), `llms.txt`, HTTP skill template in `utils.ts` (`createHttpDocsSkill`).
- Telemetry properties: stop sending `environmentsFolder`; optional event note `envLocation: projectRoot`.

## Step 8 — Verify

- `npm run compile`
- Manual: `.env` + `.env.dev` na raiz; `.req` com `# @env dev`; hover; execute request; select environment command.

## Files (expected touch list)

| File | Change |
|------|--------|
| `src/utils.ts` | Root env helpers; remove environments path helpers |
| `src/environmentManager.ts` | Root paths, watchers, init |
| `src/httpEnvironmentProviders.ts` | User-facing paths |
| `src/envCodeLensProvider.ts` | Root env files |
| `src/extension.ts` | Commands |
| `src/shareableGenerator.ts` | Bundle paths |
| `src/shareableImporter.ts` | Import destination |
| `package.json` | Settings, menus |
| `README.md`, `CHANGELOG.md`, `llms.txt` | Breaking + migration |

## Risks

- Usuários com envs só na pasta antiga precisam mover manualmente.
- `.env.local` como env `local` pode confundir com “override” dotenv — documentar que `# @env local` carrega `.env.local`.

## Rollback

Reverter commit; restaurar setting `environmentsFolder` apenas se necessário (não planejado).
