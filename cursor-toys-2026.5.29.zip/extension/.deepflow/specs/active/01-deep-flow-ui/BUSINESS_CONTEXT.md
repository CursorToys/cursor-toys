# Business Context — DeepFlow UI in CursorToys

## Problem

DeepFlow today lives only as a **skill + folder convention** (`.deepflow/specs/{drafts,active,archive}`). Users must remember slash commands (`Create task`, `Approve task`, `Complete task`) and manually inspect folders to see what is in draft vs active vs archived. There is no first-class UI inside CursorToys while working on the extension (or any repo using DeepFlow).

CursorToys already exposes similar workflows for **Cursor Plans** (`userPlans` tree) and personal resources, but nothing for DeepFlow tasks or stage transitions.

## Goal

Add a **DeepFlow sidebar experience** in CursorToys that mirrors the mental model of spec-driven tools (e.g. Kiro-style spec board): visible pipeline stages, per-task actions, and one-click **send to chat** so the agent can execute or gatekeep transitions.

## User Stories

1. As a developer using DeepFlow in a workspace, I see **Drafts**, **Active (in development)**, and **Archive** sections in the CursorToys explorer sidebar.
2. As a developer, I see each task as `NN-name` with a clear **stage badge** (draft / active / archive) and can expand a task to open `APPROACH.md`, `BUSINESS_CONTEXT.md`, or `COMPLETION_REPORT.md`.
3. As a tech lead, I click **Approve task** on a draft item to move it to `active/` (with confirmation), matching the DeepFlow gatekeeper.
4. As a developer, I click **Complete task** on an active item to move it to `archive/` and append an index line to `.deepflow/memory.md` (with confirmation).
5. As an executor, I click **Send to chat (execute)** on an active task to open chat with `BUSINESS_CONTEXT` + `APPROACH` so the agent implements per the immutable contract.
6. As a planner, I click **Send to chat (plan)** on a draft task to open chat with business context + a nudge to refine the draft A-B-C docs (no code).
7. As a user, when `.deepflow/` is missing, the view shows an actionable empty state (link to docs / command to initialize — chat prompt only; no auto-scaffold from extension in v1 unless trivial).
8. As a user, I can hide the DeepFlow view via existing `cursorToys.sidebar.hiddenViews` pattern (new key `deepflow`).

## Reference UX (Kiro-like, adapted)

| Kiro-like affordance | DeepFlow mapping in CursorToys |
|----------------------|--------------------------------|
| Specs / work items list | Tree: stages → tasks → A-B-C files |
| “In progress” | `active/` section label **In development** |
| Approve / promote | `Approve task` → `drafts/` → `active/` |
| Run / implement | `Send to chat (execute)` with active task docs |
| Done | `Complete task` → `archive/` + `memory.md` index |

## Out of Scope (v1)

- Editing A-B-C files inside a custom webview (use normal editor).
- Running automated tests from the tree (no test runner in repo yet).
- Multi-root workspace aggregation (first workspace folder with `.deepflow` only).
- Replacing the DeepFlow **skill**; extension complements slash/chat workflow.
- Auto-generating `AGENTS.md` on init (keep as chat/skill responsibility).
- Creating new draft tasks from UI (optional v1.1; v1 focuses on visibility + transitions + chat).
- Conflict resolution when two tasks share the same `NN` prefix across stages (assume well-formed folders).

## Acceptance Criteria

- [ ] New explorer view `cursor-toys.deepflow` (title **DeepFlow** or **Specs**) registered in `package.json`.
- [ ] Tree lists three stage groups when `.deepflow/specs` exists: **Drafts**, **In development** (`active`), **Archive**.
- [ ] Tasks sorted by numeric prefix ascending within each stage; invalid folder names skipped with log only.
- [ ] Task node shows `NN-name`; child nodes for the three A-B-C files when present.
- [ ] File click opens the markdown file in the editor.
- [ ] Command `cursor-toys.deepflow.approveTask` moves selected draft folder to `active/`; shows error if not in drafts; confirmation dialog.
- [ ] Command `cursor-toys.deepflow.completeTask` moves selected active folder to `archive/`; appends `[YYYY-MM-DD] [NN]: <summary>. Ref: specs/archive/...` to `memory.md` (summary from one-line user input or first heading in `BUSINESS_CONTEXT.md`); confirmation dialog.
- [ ] Command `cursor-toys.deepflow.sendToChatExecute` sends active task `BUSINESS_CONTEXT.md` + `APPROACH.md` (truncate or warn if over deeplink limit).
- [ ] Command `cursor-toys.deepflow.sendToChatPlan` sends draft task `BUSINESS_CONTEXT.md` + instruction to stay in planning mode.
- [ ] Command `cursor-toys.deepflow.refresh` + FileSystemWatcher on `.deepflow/specs/**` refreshes tree.
- [ ] `cursorToys.sidebar.hiddenViews` accepts `deepflow`; view `when` uses `cursorToys.sidebar.deepflowVisible`.
- [ ] Telemetry events for approve, complete, send-to-chat (reuse `TelemetryManager` patterns).
- [ ] `CHANGELOG.md` entry; `npm run compile` clean.
- [ ] Manual test plan documented in `COMPLETION_REPORT.md` on completion.

## Manual Test Plan

1. Open `cursor-toys` repo (has `.deepflow/`). Sidebar shows DeepFlow view with Drafts / In development / Archive.
2. Approve a draft task → folder moves to `active/`; tree updates without window reload.
3. Send to chat (execute) on active task → chat opens with both docs.
4. Complete active task → folder in `archive/`; new line in `memory.md`.
5. Hide `deepflow` in `cursorToys.sidebar.hiddenViews` → view disappears.
6. Open workspace without `.deepflow` → empty state message with guidance.

## Success Metrics

- DeepFlow stage and task status visible without opening the file explorer manually.
- Approve / complete / execute-in-chat achievable from sidebar in &lt; 3 clicks.
