# Approach — DeepFlow UI in CursorToys

**Task size:** Large  
**Estimated effort:** 1–2 days

## Design Decisions

| Topic | Decision |
|-------|----------|
| UI pattern | Mirror `UserPlansTreeProvider`: `TreeDataProvider` + `createTreeView` + context menus |
| DeepFlow root | `{workspaceFolder}/.deepflow` — first folder in `vscode.workspace.workspaceFolders` |
| Specs path | `.deepflow/specs/{drafts,active,archive}/` |
| Task folder regex | `^\d{2,}-[\w-]+$` (align with skill) |
| Stage moves | `vscode.workspace.fs.rename` (same volume) |
| Chat injection | Reuse `sendToChat()` from `src/sendToChat.ts` |
| Approve/complete copy | English user-facing strings (project convention) |
| Sidebar hide | Extend `sidebarVisibility.ts` with key `deepflow` |

## Architecture

```mermaid
flowchart TB
  subgraph UI
    TV[DeepFlowTreeProvider]
    V[cursor-toys.deepflow view]
  end
  subgraph FS
    D[drafts/]
    A[active/]
    R[archive/]
    M[memory.md]
  end
  TV --> D
  TV --> A
  TV --> R
  Approve[approveTask] --> D
  Approve --> A
  Complete[completeTask] --> A
  Complete --> R
  Complete --> M
  Chat[sendToChat*] --> sendToChat.ts
  W[FileSystemWatcher] --> TV
```

## Tree Model

```typescript
// Conceptual types (implement in deepflowTreeProvider.ts)
type DeepFlowStage = 'drafts' | 'active' | 'archive';
type DeepFlowItemType = 'stage' | 'task' | 'abcFile';

interface DeepFlowTreeItem {
  type: DeepFlowItemType;
  stage?: DeepFlowStage;
  taskId?: string;      // e.g. "01-deep-flow-ui"
  taskFolderUri?: Uri;  // .../specs/drafts/01-deep-flow-ui
  abcFile?: 'APPROACH' | 'BUSINESS_CONTEXT' | 'COMPLETION_REPORT';
  label: string;
}
```

**Labels**

| Node | Label example | `contextValue` |
|------|---------------|----------------|
| Stage | `Drafts` / `In development` / `Archive` | `deepflowStage` + suffix `Drafts` etc. |
| Task | `01-deep-flow-ui` | `deepflowTaskDraft` / `deepflowTaskActive` / `deepflowTaskArchive` |
| File | `APPROACH.md` | `deepflowAbcFile` |

**Icons (ThemeIcon)**

- Stage: `layers` / `sync~spin` for active / `archive`
- Task draft: `git-pull-request-draft` or `lightbulb`
- Task active: `debug-start`
- Task archive: `check`
- A-B-C: `book` / `target` / `report`

## Implementation Steps

### Step 1 — DeepFlow path helpers

**New file:** `src/deepflowPaths.ts`

- `getDeepflowRootUri(workspaceFolder): Uri | undefined`
- `getDeepflowSpecsUri(root): Uri`
- `parseTaskFolderName(name): { num: number; slug: string } | null`
- `listTasksInStage(specsUri, stage): Promise<DeepFlowTaskInfo[]>`
- `readAbcFile(taskUri, which): Promise<string | undefined>`
- Constants: `STAGES`, `ABC_FILES`

No VS Code UI in this file (pure helpers for testability later).

### Step 2 — Tree provider

**New file:** `src/deepflowTreeProvider.ts`

- Implement `vscode.TreeDataProvider<DeepFlowTreeItem>`
- `getChildren`: stage → tasks → abc files (only if file exists on disk)
- `refresh()` + `onDidChangeTreeData`
- Empty root: single informational item if no `.deepflow/specs` (optional `TreeItem` with no command)

### Step 3 — Stage transition service

**New file:** `src/deepflowTaskOps.ts`

- `approveTask(taskFolderUri): Promise<void>` — validate parent is `drafts`, rename to `active/NN-name`, show success message
- `completeTask(taskFolderUri, summary?: string): Promise<void>` — validate parent is `active`, rename to `archive/`, append memory index line (date ISO, extract `NN` from folder name)
- `buildMemoryIndexLine(taskFolderName, summary): string` — format per skill
- Guardrails: confirm dialogs via `showWarningMessage` + modal; catch rename errors

### Step 4 — Chat prompt builders

**New file:** `src/deepflowChatPrompts.ts`

- `buildExecutePrompt(bc: string, approach: string, taskId: string): string` — instruct agent: active contract, TDD, follow APPROACH steps, update COMPLETION_REPORT
- `buildPlanPrompt(bc: string, taskId: string): string` — instruct: draft only, no code, refine A-B-C
- `buildApprovePrompt(taskId: string): string` — short message: user approved in UI; agent should acknowledge gatekeeper (optional, for users who still use chat for bookkeeping)

Truncate body if combined length risks `MAX_DEEPLINK_LENGTH` (show warning, offer copy to clipboard fallback).

### Step 5 — Commands + extension wiring

**File:** `src/extension.ts`

Register commands:

| Command ID | Behavior |
|------------|----------|
| `cursor-toys.deepflow.refresh` | `provider.refresh()` |
| `cursor-toys.deepflow.approveTask` | From tree selection `deepflowTaskDraft` |
| `cursor-toys.deepflow.completeTask` | From `deepflowTaskActive`; input box for summary |
| `cursor-toys.deepflow.sendToChatExecute` | Active task only |
| `cursor-toys.deepflow.sendToChatPlan` | Draft task only |
| `cursor-toys.deepflow.openAbcFile` | Open md (inline click) |

- `createTreeView('cursor-toys.deepflow', { treeDataProvider })`
- FileSystemWatcher: `**/.deepflow/specs/**` → debounced refresh
- Telemetry: `deepflow-approve`, `deepflow-complete`, `deepflow-send-chat`, stage in properties

### Step 6 — package.json contributions

- `views.explorer`: id `cursor-toys.deepflow`, name `DeepFlow`, `when: cursorToys.sidebar.deepflowVisible`
- `menus.view/title`: refresh
- `menus.view/item`: inline open + grouped actions per `contextValue`
- `activationEvents`: `onView:cursor-toys.deepflow` (optional; `onStartupFinished` already covers)
- Configuration: extend `cursorToys.sidebar.hiddenViews` enum with `"deepflow"`

### Step 7 — Sidebar visibility

**File:** `src/sidebarVisibility.ts`

- Add `deepflow` to `SidebarResourceKey` and `ALL_SIDEBAR_RESOURCE_KEYS`
- Context key `cursorToys.sidebar.deepflowVisible`

### Step 8 — Documentation

- `CHANGELOG.md` — Added: DeepFlow sidebar view
- `llms.txt` — brief command list (if other views documented there)
- Root `AGENTS.md` — optional one bullet under structure pointing to `deepflowTreeProvider.ts`

## Files Touched (expected)

| File | Action |
|------|--------|
| `src/deepflowPaths.ts` | Create |
| `src/deepflowTreeProvider.ts` | Create |
| `src/deepflowTaskOps.ts` | Create |
| `src/deepflowChatPrompts.ts` | Create |
| `src/extension.ts` | Wire view, commands, watcher |
| `src/sidebarVisibility.ts` | Add `deepflow` key |
| `package.json` | View, menus, commands, setting enum |
| `CHANGELOG.md` | Entry |

## Risks & Mitigations

| Risk | Mitigation |
|------|------------|
| Chat payload too large | Truncate with notice or clipboard copy |
| Rename across devices fails | Only support same-workspace rename; clear error |
| Two active tasks with same NN | Rare; show error on collision in target stage |
| User expects UI to create drafts | Document out of scope; link to skill command |
| `memory.md` missing | Create with header template on first complete |

## Sequence — Approve flow

```mermaid
sequenceDiagram
  participant U as User
  participant E as Extension
  participant FS as workspace.fs
  U->>E: Approve task
  E->>E: Confirm dialog
  E->>FS: rename drafts/NN → active/NN
  FS-->>E: OK
  E->>E: refresh tree + telemetry
  E->>U: Plan approved message
```

## Dependency on other work

- `00-hide-sidebar-resource-views` (active): ensure `deepflow` added to hiddenViews enum when that task lands; if not merged, include `deepflow` in this task's `package.json` change either way.
