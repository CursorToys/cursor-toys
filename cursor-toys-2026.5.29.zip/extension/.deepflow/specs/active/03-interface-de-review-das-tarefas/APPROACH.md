# [A] APPROACH — 03-interface-de-review-das-tarefas

> **The Blueprint.** Technical solution design and step-by-step execution plan.
> Once this task enters `active/`, this file is **immutable** without re-approval.

## Summary

Introduce a **DeepFlow Spec Review** webview panel that opens when users click A-B-C files in the DeepFlow tree. The panel renders markdown with line numbers, supports **range-anchored comments**, aggregates them per task, **sends a structured review payload to Cursor chat**, and exposes an **Approve** action (draft → existing Approve task flow; active → LGTM only). Raw editor access remains via an explicit **Open in editor** action. Reuse existing patterns: `AnnotationPanel` / `ReleaseNotesPanel` webviews, `sendDeepflowToChat`, `buildApproveChatMessage`, and `deepflowTreeProvider` command wiring.

## Affected Files

| File | Change | Rationale |
|---|---|---|
| `src/deepflowReviewPanel.ts` | create | Webview UI, comment model, markdown+lines render, chat payload |
| `src/deepflowReviewSession.ts` | create | In-memory comment store keyed by task folder URI |
| `src/deepflowFileOps.ts` | modify | Add `openDeepflowSpecReview`; keep `openDeepflowSpecFile` for editor |
| `src/deepflowTreeProvider.ts` | modify | Tree click → review; context menu / alt command → editor |
| `src/extension.ts` | modify | Register `cursor-toys.deepflow.openReview`, `openAbcFileInEditor` |
| `package.json` | modify | Commands, tree context menus, webview panel contribution |
| `src/telemetry.ts` | modify | Review events |
| `README.md` | modify | Document review UX under DeepFlow |
| `CHANGELOG.md` | modify | Feature entry |
| `llms.txt` | modify | Command list for agents |

## Dependencies & Constraints

- No new npm dependencies; markdown rendering via lightweight in-extension conversion (reuse approach from `releaseNotesPanel.ts` `markdownToHtml` or extract shared helper).
- Webview `enableScripts: true`, `retainContextWhenHidden: true` (same as `AnnotationPanel`).
- Comments are **session-scoped** in v1 (cleared when window reloads); no `.deepflow/reviews/` persistence unless open question resolved during implementation.
- Must not break existing commands: `openAbcFile` becomes review by default; editor path exposed explicitly.
- English for all user-facing strings and code comments.

## Execution Plan (atomic steps)

1. **Step 1 — Review session model**
   - Files: `src/deepflowReviewSession.ts`
   - Define `DeepflowReviewComment` (`id`, `fileUri`, `startLine`, `endLine`, `excerpt`, `body`, `createdAt`).
   - API: `addComment`, `listForTask`, `listForFile`, `clearTask`, `formatForChat(taskUri, stage)`.
   - Done when: unit-testable pure functions (export for manual test via compile).

2. **Step 2 — Review webview panel**
   - Files: `src/deepflowReviewPanel.ts`
   - `DeepflowReviewPanel.createOrShow({ fileUri, taskFolderUri, stage, abcKind })`.
   - Load file content via `vscode.workspace.fs`; render HTML with line gutter + markdown body.
   - Webview messages: `addComment`, `removeComment`, `sendToChat`, `approve`, `openInEditor`.
   - Toolbar actions mirror webview buttons.
   - Done when: panel opens from a test command with one file and displays lines.

3. **Step 3 — Wire tree and commands**
   - Files: `src/deepflowTreeProvider.ts`, `src/deepflowFileOps.ts`, `src/extension.ts`, `package.json`
   - Change A-B-C tree `command` from `openAbcFile` → `openReview` (pass `fileUri`, derive `taskFolderUri` + `stage` from path under `specs/{drafts|active|archive}`).
   - Add `cursor-toys.deepflow.openAbcFileInEditor` for context menu on `deepflowAbcFile`.
   - Archive tasks: hide Approve or show read-only banner.
   - Done when: click in tree opens review; context menu opens editor.

4. **Step 4 — Send review to chat**
   - Files: `src/deepflowReviewPanel.ts`, `src/deepflowChatPrompts.ts` (optional helper)
   - Build message:
     ```
     @.deepflow/specs/drafts/03-...

     Review feedback (please update the spec, no code):

     ### BUSINESS_CONTEXT.md L12–18
     > excerpt
     Comment: ...
     ```
   - Call `sendDeepflowToChat` with `submit: true`.
   - Done when: manual test pastes structured comments in composer.

5. **Step 5 — Approve actions**
   - Draft: confirm → `buildApproveChatMessage` + send (or invoke existing approve command after confirm).
   - Active: `showInformationMessage` LGTM; optional minimal chat line “Spec review approved (LGTM).”
   - Done when: draft approve matches existing gatekeeper; active does not move folders.

6. **Step 6 — Telemetry, docs, validation**
   - Files: `src/telemetry.ts`, `README.md`, `CHANGELOG.md`, `llms.txt`
   - `npm run compile` clean; manual test plan in COMPLETION_REPORT.
   - Done when: AC-1–AC-7 verified manually.

## Risks & Mitigations

| Risk | Likelihood | Mitigation |
|---|---|---|
| Markdown render ≠ editor line mapping | med | Render from **source lines** array; map selection on raw text indices, not HTML DOM alone |
| Large spec files slow webview | low | Cap excerpt length; warn if file &gt; 500 KB |
| Approve confused with Complete task | med | Clear button labels: **Approve spec** vs existing **Complete task** in tree |
| XSS in webview HTML | low | Escape user comment bodies; sanitize markdown HTML output |

## Out of Scope

- Inline editing of A-B-C inside the webview (use **Open in editor**).
- Persisting review threads to disk or GitLab/GitHub sync.
- Multi-root workspace aggregation (same as `01-deep-flow-ui`).
- Replacing DeepFlow skill commands; extension complements chat workflow.
- Automated tests (no harness in repo; manual checklist only).

## Diagram

```mermaid
sequenceDiagram
  participant User
  participant Tree as DeepFlowTree
  participant Review as SpecReviewPanel
  participant Session as ReviewSession
  participant Chat as sendDeepflowToChat

  User->>Tree: Click APPROACH.md
  Tree->>Review: openReview(file, task, stage)
  Review->>User: Render MD + line gutter
  User->>Review: Select lines + add comment
  Review->>Session: addComment(...)
  User->>Review: Send review to chat
  Review->>Session: formatForChat()
  Session->>Chat: structured payload + @task
  Chat->>User: Composer filled/submitted
  User->>Review: Approve (draft)
  Review->>Chat: @task + Approve task
```
