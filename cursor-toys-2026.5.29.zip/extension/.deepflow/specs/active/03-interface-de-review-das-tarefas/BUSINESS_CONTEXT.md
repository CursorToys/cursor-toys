# [B] BUSINESS CONTEXT — 03-interface-de-review-das-tarefas

> **The Goal.** Why this task exists and how we'll know it's done.
> Acceptance Criteria here drive TDD in the Active stage.

## Problem Statement

Today, clicking an A-B-C file (`APPROACH.md`, `BUSINESS_CONTEXT.md`, `COMPLETION_REPORT.md`) in the DeepFlow tree opens it as a **plain text editor** (`openDeepflowSpecFile` with `preview: false`). Reviewing a spec feels like editing a file, not like a **code review**: there is no way to anchor comments to line ranges, collect feedback in one place, send structured review notes to the agent, or explicitly **approve** the spec when satisfied.

Tech leads and reviewers need a **read-focused preview** (similar to GitLab/GitHub merge request review) while planning or gatekeeping DeepFlow tasks—especially in **draft** (plan review) and **active** (implementation contract review) stages.

## User Story

> As a **tech lead or reviewer**, I want to **open DeepFlow spec files in a review preview where I can comment on blocks/lines, send those comments to chat for adjustments, and approve when ready** so that **spec review feels like a lightweight CR without leaving CursorToys**.

## Business Value

- Impact: Faster, clearer spec reviews; fewer back-and-forth messages; explicit approve vs “request changes” flow.
- Priority: **high** (core UX gap after DeepFlow panel shipped in `01-deep-flow-ui`).
- Stakeholder(s): Developers using DeepFlow in CursorToys; reviewers before `Approve task` / during active execution.

## Acceptance Criteria (TDD targets)

- **AC-1 — Review preview opens from tree**
  - **Given** DeepFlow panel is enabled and a task has A-B-C files
  - **When** the user clicks an A-B-C file in the DeepFlow tree (primary click)
  - **Then** a **Spec Review** webview opens beside the editor showing rendered markdown with **line numbers** aligned to the source file (not the raw editor as default).

- **AC-2 — Block / line comments**
  - **Given** the review preview is open
  - **When** the user selects a line range (or clicks “add comment” on a section) and enters text
  - **Then** a comment thread is shown anchored to that range (file path + start/end line); multiple comments can exist in one session.

- **AC-3 — Send review to chat**
  - **Given** one or more review comments exist for the current task (across one or more A-B-C files opened in review during the session)
  - **When** the user clicks **Send review to chat**
  - **Then** the composer receives a structured message: `@<task-folder>`, task stage, list of comments (file, lines, quoted excerpt, reviewer note), and a clear instruction for the agent to **revise the spec** (no implementation code); uses existing `sendDeepflowToChat` / inject pipeline with paste-and-submit.

- **AC-4 — Approve (CR-style)**
  - **Given** the review preview is open for a task in **draft**
  - **When** the user clicks **Approve**
  - **Then** a confirmation dialog explains that this approves the spec review and may run DeepFlow **Approve task** (draft → active); on confirm, sends `@<task-folder>` + `Approve task` to chat (same contract as existing approve action) OR runs the existing folder move command—behavior must match current gatekeeper semantics and remain confirmable.

- **AC-5 — Approve on active task (LGTM, no stage change)**
  - **Given** the task is in **active**
  - **When** the user clicks **Approve**
  - **Then** the user sees success feedback (“Spec review approved”) and **no folder move** occurs; optional: send a short LGTM message to chat without `Complete task`.

- **AC-6 — Open in editor (escape hatch)**
  - **Given** the review preview is open
  - **When** the user chooses **Open in editor** (toolbar or context menu on tree item)
  - **Then** the underlying markdown file opens in the normal editor (current `openDeepflowSpecFile` behavior).

- **AC-7 — Telemetry and docs**
  - **Given** review actions run
  - **When** open review, add comment, send to chat, or approve
  - **Then** `TelemetryManager` records events; `CHANGELOG.md` and DeepFlow section in `README.md` document the review UX.

## Non-Functional Requirements

- Performance: Render typical spec files (&lt; 200 KB) without blocking the UI; debounce selection if needed.
- Accessibility: Keyboard-focusable comment input; sufficient contrast in webview theme (follow VS Code webview CSS variables).
- Telemetry: `deepflow.review.open`, `deepflow.review.comment`, `deepflow.review.sendToChat`, `deepflow.review.approve` (names illustrative—match existing naming in `telemetry.ts`).
- Compatibility: Works when `cursorToys.experimental.deepflow` is on; no change when panel is disabled.

## Open Questions

- [ ] **Persist comments?** v1 session-only in webview vs save under `.deepflow/reviews/<NN-name>/` for async review (recommend session-only for v1; note in APPROACH).
- [ ] **Multi-file review session:** Should comments from `BUSINESS_CONTEXT` and `APPROACH` aggregate in one “Send review to chat” payload? (Recommend **yes** per task folder session.)
- [ ] **Archive stage:** Open review read-only (comments allowed but Approve hidden)? (Recommend **yes**.)

## Success Metric

- Reviewers can complete a draft spec review (read → comment → send to chat → approve) **without manually opening the file explorer** or copying line numbers into chat.
- Reduction in unstructured “please fix the spec” chat messages (qualitative feedback from team).
