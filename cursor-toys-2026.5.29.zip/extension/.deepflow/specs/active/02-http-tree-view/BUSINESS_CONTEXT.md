# Business Context — HTTP Tree View in Sidebar

## Problem

HTTP request files (`.req` / `.request` under `.{baseFolder}/http/`) are only discoverable via the file explorer or by opening files manually. Individual requests inside a file are visible only through **CodeLens** when the file is open. Users who rely on the CursorToys sidebar for Commands, Prompts, and Skills expect the same pattern for HTTP: browse files, see each request (`##` section or standalone `curl`), and run a request without hunting in the editor.

## Goal

Add an **HTTP** section to the Explorer sidebar that mirrors the recursive folder layout of Prompts/Skills, expands each file into its request blocks, and lets the user **send** a request (or open the file) from the tree.

## User Stories

1. As a developer, I see an **HTTP** view in the sidebar (when not hidden) listing all `.req` / `.request` files under the workspace `http/` folder, including subfolders.
2. As a developer, when I expand a file node, I see one child per request block (`## Title` sections and standalone `curl` commands), with a label that identifies the request (section title or `curl` + method hint when possible).
3. As a developer, I click a request node and the extension runs the same flow as **Send Request** CodeLens (`cursor-toys.sendHttpRequest`).
4. As a developer, I can open the underlying file from the tree (file node) like other resource trees.
5. As a developer, I can hide the HTTP view via `cursorToys.sidebar.hiddenViews` like other resource sections.
6. As a developer, the tree refreshes when files are added, removed, or changed under `http/`.

## Out of Scope

- Personal/global HTTP folders outside the workspace (HTTP is project-scoped only).
- Drag-and-drop between folders (can follow in a later task; Prompts have DnD, HTTP tree v1 is read + execute).
- Running **Run assertions** / CLI test from the tree (CodeLens/terminal only for v1).
- Listing project-root `.env*` files in this tree (environments stay in editor/status bar).
- Duplicate tree in the DeepFlow activity bar.

## Acceptance Criteria

- [ ] New explorer view `cursor-toys.userHttp` named **HTTP**, gated by `cursorToys.sidebar.httpVisible` (default visible).
- [ ] `http` added to `cursorToys.sidebar.hiddenViews` enum and `sidebarVisibility.ts` (`SidebarResourceKey`).
- [ ] Tree shows workspace category (project name) → folders → `.req`/`.request` files → request children.
- [ ] Request children match CodeLens parsing: `##` sections (with inherited `# @env`) and uncovered `curl` lines.
- [ ] Clicking a request child executes `cursor-toys.sendHttpRequest` with `(uri, startLine, endLine, sectionTitle)`.
- [ ] Clicking a file child opens the file in the editor (same pattern as prompts).
- [ ] Refresh command on view title + `FileSystemWatcher` on `{workspace}/.{baseFolder}/http/**`.
- [ ] Shared parser module used by tree and `HttpCodeLensProvider` (no duplicated parsing logic).
- [ ] `npm run compile` passes; `CHANGELOG.md` entry under Added.
- [ ] Manual: sample file with two `##` sections and one standalone `curl` — tree shows three runnable children; send works from tree.

## Manual Test Plan

1. Open a workspace with `.cursor/http/api.req` containing two `##` sections and one `curl` block.
2. Confirm **HTTP** appears in sidebar; expand project → folder → file → see three request nodes.
3. Click first request node → request runs; response panel opens as with CodeLens.
4. Add `http` to `cursorToys.sidebar.hiddenViews` → view disappears; remove → reappears.
5. Add a new `.req` file on disk → refresh or watcher updates tree without window reload.
