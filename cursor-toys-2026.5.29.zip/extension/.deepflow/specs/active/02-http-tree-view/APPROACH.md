# Approach — HTTP Tree View in Sidebar

**Task size:** Medium  
**Estimated effort:** half day (~4–6 h)

## Design Decisions

| Topic | Decision |
|-------|----------|
| UI pattern | Mirror `UserPromptsTreeProvider`: workspace-only category, recursive folders, file leaves |
| Request children | New item type `request` under each file; parse via shared `httpRequestParser.ts` |
| Execution | Reuse `cursor-toys.sendHttpRequest` (same args as CodeLens) |
| File open | File node → `cursor-toys.openHttpRequest` or inline `vscode.open` at line 0 |
| Extensions | `.req`, `.request` only (`isHttpRequestFile` / path under `getHttpPath`) |
| Parser DRY | Extract `parseRequestSections` (+ standalone curl discovery) from `httpCodeLensProvider.ts` |
| Visibility | Extend `sidebarVisibility.ts` with key `http`; `package.json` view `when` clause |
| Watcher | `FileSystemWatcher` on `**/.{baseFolder}/http/**` (respect `getBaseFolderName()`) |

## Tree Model

```typescript
type HttpTreeItemType = 'category' | 'folder' | 'file' | 'request';

interface HttpTreeItem {
  type: HttpTreeItemType;
  uri: vscode.Uri;
  fileName: string;
  filePath: string;
  folderPath?: string;
  children?: HttpTreeItem[];
  // request-only
  startLine?: number;
  endLine?: number;
  sectionTitle?: string;
  requestLabel?: string; // display: section title or "curl (line N)"
  envName?: string | null; // optional suffix in description
}
```

**Labels & icons**

| Node | Label | `contextValue` | Icon |
|------|-------|----------------|------|
| Category | `{workspaceName} (workspace)` | `httpCategory` | `folder` |
| Folder | folder name | `httpFolder` | `folder` |
| File | `api.req` | `httpFile` | `file` |
| Request | `##` title or `Send curl` | `httpRequest` | `play` / `debug-start` |

Optional `description` on request nodes: env badge when section has variables and `envName` is set (mirror CodeLens title logic lightly).

## Architecture

```mermaid
flowchart TB
  subgraph Sidebar
    TV[UserHttpTreeProvider]
    V[cursor-toys.userHttp]
  end
  subgraph Parse
    P[httpRequestParser.ts]
  end
  subgraph Existing
    CL[HttpCodeLensProvider]
    EX[executeHttpRequestFromFile]
    CMD[cursor-toys.sendHttpRequest]
  end
  TV --> P
  CL --> P
  TV -->|click request| CMD
  CMD --> EX
  W[FileSystemWatcher http/**] --> TV
```

## Implementation Steps

### Step 1 — Extract HTTP request parser

- Create `src/httpRequestParser.ts` exporting:
  - `RequestSection` interface (title, titleLine, startLine, endLine, envName)
  - `parseRequestSections(document: vscode.TextDocument): RequestSection[]`
  - `findStandaloneCurlBlocks(document, coveredLines): RequestSection[]` (logic moved from CodeLens)
- Update `HttpCodeLensProvider` to import parser; behavior unchanged.

### Step 2 — `UserHttpTreeProvider`

- New file `src/userHttpTreeProvider.ts`:
  - `readDirectoryRecursive` for `getHttpPath(workspace)` — filter `.req`/`.request`
  - `groupFilesByFolder` (copy pattern from prompts, simplified — workspace only)
  - `getChildren`: lazy-load request children when expanding a `file` node (read file via `vscode.workspace.fs` or `openTextDocument`)
  - `getTreeItem`: file → open command; request → `sendHttpRequest` command with line range

### Step 3 — Register in `extension.ts`

- `createTreeView('cursor-toys.userHttp', { treeDataProvider })`
- Register `cursor-toys.refreshUserHttp`
- Register `cursor-toys.openHttpRequest` (open file, optional reveal line for request parent file)
- FileSystemWatcher on workspace `http` path; refresh on create/change/delete
- Call `syncSidebarViewVisibility` already handles new key after Step 4

### Step 4 — `package.json` contributions

- View under `explorer`: `cursor-toys.userHttp`, name `HTTP`, `when: cursorToys.sidebar.httpVisible`
- `activationEvents`: `onView:cursor-toys.userHttp`
- `view/title`: refresh command
- `view/item/context`: optional — Open file, Send request (if not using click on request)
- Setting enum: add `http` to `cursorToys.sidebar.hiddenViews`

### Step 5 — `sidebarVisibility.ts`

- Add `'http'` to `SidebarResourceKey`, `ALL_SIDEBAR_RESOURCE_KEYS`, `VISIBILITY_CONTEXT_KEYS`

### Step 6 — Docs & telemetry

- `CHANGELOG.md` Added entry
- Optional: `telemetry.trackCommand` for `refreshUserHttp` / tree send (follow existing HTTP events)
- Update `llms.txt` / README sidebar list if documented elsewhere

## Files Touched (expected)

| File | Action |
|------|--------|
| `src/httpRequestParser.ts` | Create |
| `src/userHttpTreeProvider.ts` | Create |
| `src/httpCodeLensProvider.ts` | Refactor imports |
| `src/extension.ts` | Register view, watcher, commands |
| `src/sidebarVisibility.ts` | Add `http` key |
| `package.json` | View, menus, setting enum |
| `CHANGELOG.md` | Entry |

## Risks

| Risk | Mitigation |
|------|------------|
| Large files slow tree expand | Parse only on expand; cache per uri until watcher fires |
| Parser drift vs CodeLens | Single module + manual test with multi-section file |
| Multi-root workspace | v1: first workspace folder only (same as several existing providers) |

## Dependencies

- Existing: `getHttpPath`, `isHttpRequestFile`, `executeHttpRequestFromFile`, `sendHttpRequest` command
- No CLI changes required for v1
