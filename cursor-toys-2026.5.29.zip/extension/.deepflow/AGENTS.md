# DeepFlow AGENTS — cursor-toys

## Tech Stack

| Layer | Choice |
|-------|--------|
| Language | TypeScript (strict), target ES2020 |
| Runtime | Node.js, CommonJS modules |
| Platform | VS Code / Cursor Extension API (`engines.vscode` ^1.74.0) |
| Build | `tsc` → `out/` (`npm run compile`, `npm run watch`) |
| Package | `vsce` (`npm run package`, `npm run publish`) |

## Coding Standards

- Follow root `AGENTS.md`: English for code, comments, user-facing strings, commits.
- camelCase files/functions; PascalCase classes; UPPER_SNAKE_CASE constants.
- Use helpers in `src/utils.ts` for paths (`getHttpPath`, `getBaseFolderName`) — never hardcode `.cursor/`.
- Errors: `vscode.window.showErrorMessage`, validate early, avoid unhandled throws.
- Telemetry via `TelemetryManager` for new commands/events.

## Testing Setup

- No automated test runner in repo today (manual: compile + install `.vsix` + exercise commands).
- DeepFlow tasks should define acceptance criteria as manual checklists until a test harness exists.
- Always run `npm run compile` and fix type errors before completion.

## Agent Personas

| Persona | Focus |
|---------|--------|
| **Extension engineer** | `extension.ts`, commands, `package.json` contributions |
| **HTTP feature owner** | `environmentManager.ts`, `httpRequestExecutor.ts`, `httpEnvironmentProviders.ts`, share/import |
| **Docs maintainer** | `README.md`, `CHANGELOG.md`, `llms.txt`, HTTP skill text in `utils.ts` |

## HTTP Environments

- Variables live at the **workspace root**: `.env`, `.env.local`, `.env.dev`, etc.
- Decorator `# @env <name>` in `.req` / `.request` files; `default` → `.env` at project root.
- No `http/environments` or `cursorToys.environmentsFolder` setting.

## Breaking-change policy

- Document removals in `CHANGELOG.md` under a **Breaking Changes** section.
- Bump minor/major per project release practice when removing settings or folder layout.
